# Km Justo 3.0 — base de atualização

- Interface escura com acentos neon verde/azul.
- Cálculo estimado por km considerando consumo por modo, combustível, custos mensais rateados e pedágio/outros.
- Configuração de meta de lucro por hora e por km.
- Bolha Android de análise manual com permissão de sobreposição; não lê automaticamente ofertas de Uber/99 e não aceita/rejeita corridas.
- Dados locais preservados por localStorage `kmjusto-v3` e migração de leitura da chave `kmjusto-v2`.

## Gerar APK pelo GitHub
1. Extraia este ZIP.
2. Envie o conteúdo da pasta `kmjusto/` para a raiz do repositório GitHub (inclua `app/`, `build.gradle`, `settings.gradle` e `.github/`).
3. Abra Actions > Gerar APK Km Justo > Run workflow (ou faça commit na branch principal).
4. Abra a execução concluída e baixe o artefato `KmJusto-apk`.

## Limitações importantes
O cálculo é uma estimativa: use consumo real, preço real do combustível e km/tempo totais incluindo deslocamento até a coleta e retorno vazio quando aplicável. A bolha recebe manualmente valor/km/tempo. Ela não extrai automaticamente o conteúdo de outros apps. O projeto ainda precisa ser compilado e testado em aparelho real; o APK não foi validado neste ambiente.
