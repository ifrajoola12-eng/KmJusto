package com.kmjusto.app;

import android.app.Service;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import java.text.NumberFormat;
import java.util.Locale;

public class BubbleService extends Service {
    public static final String ACTION_TOGGLE="com.kmjusto.app.TOGGLE_BUBBLE";
    private WindowManager wm; private View bubble; private View panel; private boolean expanded=false;
    private int x,y; private final String channel="kmjusto_bubble";
    @Override public void onCreate(){super.onCreate();wm=(WindowManager)getSystemService(WINDOW_SERVICE);createChannel();}
    private void createChannel(){if(Build.VERSION.SDK_INT>=26){NotificationChannel c=new NotificationChannel(channel,"Bolha Km Justo",NotificationManager.IMPORTANCE_LOW);((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);}}
    private void foreground(){Notification n;if(Build.VERSION.SDK_INT>=26)n=new Notification.Builder(this,channel).setContentTitle("Km Justo ativo").setContentText("A bolha de análise está disponível. Toque nela para analisar uma oferta.").setSmallIcon(android.R.drawable.ic_menu_info_details).setOngoing(true).build();else n=new Notification.Builder(this).setContentTitle("Km Justo ativo").setContentText("Bolha de análise ativa").setSmallIcon(android.R.drawable.ic_menu_info_details).build();startForeground(301,n);}
    @Override public int onStartCommand(Intent intent,int flags,int startId){if(intent!=null&&ACTION_TOGGLE.equals(intent.getAction())){if(bubble!=null){removeViews();stopForeground(true);stopSelf();return START_NOT_STICKY;}foreground();showBubble();}return START_STICKY;}
    private WindowManager.LayoutParams params(int w,int h,int gravity){int type=Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;return new WindowManager.LayoutParams(w,h,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT);}
    private GradientDrawable bg(int color,int stroke){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(18));d.setStroke(dp(1),stroke);return d;}
    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    private TextView text(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private void showBubble(){if(!SettingsCompat.canDraw(this))return;TextView b=text("KJ",16,Color.rgb(0,25,19));b.setGravity(Gravity.CENTER);b.setBackground(bg(Color.rgb(0,230,160),Color.rgb(0,255,190)));WindowManager.LayoutParams p=params(dp(58),dp(58),Gravity.TOP|Gravity.START);p.gravity=Gravity.TOP|Gravity.START;p.x=dp(10);p.y=dp(240);bubble=b;wm.addView(bubble,p);b.setOnTouchListener(new View.OnTouchListener(){float sx,sy;int ox,oy;long down;public boolean onTouch(View v,MotionEvent e){if(e.getAction()==MotionEvent.ACTION_DOWN){sx=e.getRawX();sy=e.getRawY();ox=p.x;oy=p.y;down=System.currentTimeMillis();return true;}if(e.getAction()==MotionEvent.ACTION_MOVE){p.x=ox+(int)(e.getRawX()-sx);p.y=oy+(int)(e.getRawY()-sy);try{wm.updateViewLayout(bubble,p);}catch(Exception ignored){}return true;}if(e.getAction()==MotionEvent.ACTION_UP){if(Math.abs(e.getRawX()-sx)<10&&Math.abs(e.getRawY()-sy)<10){if(expanded)hidePanel();else showPanel();}return true;}return true;}});}
    private void showPanel(){if(panel!=null)return;expanded=true;LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(14),dp(14),dp(14),dp(12));box.setBackground(bg(Color.rgb(5,17,20),Color.rgb(0,230,160)));TextView title=text("KM JUSTO • ANALISAR",16,Color.rgb(0,230,160));box.addView(title);TextView hint=text("Digite os dados da oferta",11,Color.LTGRAY);LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,-2);hp.topMargin=dp(5);box.addView(hint,hp);
        EditText fare=input("Valor da corrida (R$)");EditText km=input("Km totais da operação");EditText mins=input("Tempo total (min)");box.addView(fare);box.addView(km);box.addView(mins);
        TextView result=text("Preencha os campos e toque em CALCULAR",12,Color.WHITE);LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.topMargin=dp(8);box.addView(result,rp);
        Button calc=new Button(this);calc.setText("CALCULAR");calc.setTextColor(Color.rgb(0,20,15));calc.setBackground(bg(Color.rgb(0,230,160),Color.rgb(0,230,160)));box.addView(calc);calc.setOnClickListener(v->{double f=val(fare),k=val(km),m=val(mins);if(f<=0||k<=0||m<=0){result.setText("Informe valor, km e tempo maiores que zero.");return;}android.content.SharedPreferences pref=getSharedPreferences("bubble",MODE_PRIVATE);double cpk=pref.getFloat("costKm",1.5f),target=pref.getFloat("targetHour",35f),minpk=pref.getFloat("minProfitKm",1.5f);double profit=f-k*cpk,pk=profit/k,h=profit/(m/60.0);String status=profit<0?"NÃO COMPENSA":(pk<minpk||h<target?"ATENÇÃO":"COMPENSA");result.setText(status+"\nLucro estimado: "+br(profit)+"\nLucro/km: "+br(pk)+"\nLucro/h: "+br(h)+"\nCusto aplicado: "+br(cpk)+"/km");result.setTextColor(status.equals("COMPENSA")?Color.rgb(0,230,160):status.equals("ATENÇÃO")?Color.rgb(255,191,36):Color.rgb(255,82,99));});
        Button close=new Button(this);close.setText("FECHAR");close.setTextColor(Color.WHITE);close.setBackground(bg(Color.rgb(17,38,43),Color.rgb(35,66,74)));box.addView(close);close.setOnClickListener(v->hidePanel());WindowManager.LayoutParams p=params(dp(300),-2,Gravity.TOP|Gravity.START);p.flags=WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;p.softInputMode=WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE|WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN;p.gravity=Gravity.TOP|Gravity.START;p.x=dp(12);p.y=dp(120);panel=box;try{wm.addView(panel,p);}catch(Exception e){panel=null;expanded=false;}}
    private EditText input(String hint){EditText e=new EditText(this);e.setSingleLine(true);e.setTextSize(14);e.setHint(hint);e.setHintTextColor(Color.GRAY);e.setTextColor(Color.WHITE);e.setInputType(8194);e.setPadding(dp(10),dp(7),dp(10),dp(7));e.setBackground(bg(Color.rgb(7,25,29),Color.rgb(35,66,74)));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(45));p.topMargin=dp(7);e.setLayoutParams(p);return e;}
    private double val(EditText e){try{return Double.parseDouble(e.getText().toString().replace(',','.'));}catch(Exception ex){return 0;}}
    private String br(double n){return NumberFormat.getCurrencyInstance(new Locale("pt","BR")).format(n);}
    private void hidePanel(){if(panel!=null){try{wm.removeView(panel);}catch(Exception ignored){}panel=null;}expanded=false;}
    private void removeViews(){hidePanel();if(bubble!=null){try{wm.removeView(bubble);}catch(Exception ignored){}bubble=null;}}
    @Override public void onDestroy(){removeViews();super.onDestroy();}
    @Override public IBinder onBind(Intent i){return null;}
    static class SettingsCompat{static boolean canDraw(android.content.Context c){return Build.VERSION.SDK_INT<23||android.provider.Settings.canDrawOverlays(c);}}
}
