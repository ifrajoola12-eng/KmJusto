package com.kmjusto.app;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.graphics.Color;
import android.view.View;

public class MainActivity extends Activity {
    private WebView web;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(3,10,12));
        getWindow().setNavigationBarColor(Color.rgb(3,10,12));
        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(3,10,12));
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Bridge(), "KmJustoBridge");
        web.loadUrl("file:///android_asset/index.html");
        setContentView(web);
    }
    private class Bridge {
        @JavascriptInterface public void saveBubbleSettings(float costKm, float targetHour, float minProfitKm) {
            getSharedPreferences("bubble", MODE_PRIVATE).edit().putFloat("costKm", Math.max(0,costKm)).putFloat("targetHour", Math.max(0,targetHour)).putFloat("minProfitKm", Math.max(0,minProfitKm)).apply();
        }
        @JavascriptInterface public void toggleBubble() { runOnUiThread(() -> {
            if (Settings.canDrawOverlays(MainActivity.this)) {
                Intent i = new Intent(MainActivity.this, BubbleService.class);
                i.setAction(BubbleService.ACTION_TOGGLE);
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
            } else {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
                startActivity(i);
            }
        }); }
        @JavascriptInterface public String getBubbleStatus() { return Settings.canDrawOverlays(MainActivity.this) ? "Permissão de sobreposição concedida. Toque em Ativar / desativar para mostrar a bolha." : "Permissão necessária: Android > Exibir sobre outros apps > Km Justo > Permitir."; }
    }
    @Override public void onBackPressed() { if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
