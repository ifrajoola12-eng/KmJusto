# Km Justo v2.0

Aplicativo Android para motoristas calcularem custo real, preço justo e resultado de corridas.

## Compilação na nuvem pelo celular

1. Crie um repositório no GitHub.
2. Envie este projeto para o repositório mantendo a pasta `.github/workflows/build-apk.yml`.
3. Abra a aba **Actions** e execute **Gerar APK Km Justo**.
4. Quando terminar, abra a execução concluída e baixe o artefato **KmJusto-apk**.
5. Dentro do artefato estará `app-debug.apk`, que pode ser instalado no Android.

## Android
- applicationId: `com.kmjusto.app`
- minSdk: 23
- targetSdk: 35
- compileSdk: 35
- Java 17 / Gradle 8.11.1 / Android Gradle Plugin 8.7.3
