package com.kmjusto.app;
import android.app.*;import android.os.*;import android.webkit.*;import android.view.*;import android.graphics.Color;
public class MainActivity extends Activity{
 @Override public void onCreate(Bundle b){super.onCreate(b); WebView w=new WebView(this); w.setBackgroundColor(Color.WHITE); w.getSettings().setJavaScriptEnabled(true);w.getSettings().setDomStorageEnabled(true);w.setOverScrollMode(View.OVER_SCROLL_NEVER);w.setWebViewClient(new WebViewClient());w.loadUrl("file:///android_asset/index.html");setContentView(w);}
}
